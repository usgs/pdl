This is the Product Distribution README.txt


Getting Started
===============
By default, the Product Client will download products and display a summary on
the screen.


Running on Windows:
	Double-click run.bat

Running on Unix:
	./run.sh



More Information
================
For more information about Product Distribution, like integrating with external
applications to send and receive products, visit the online documentation:

	https://usgs.github.io/pdl/userguide/

